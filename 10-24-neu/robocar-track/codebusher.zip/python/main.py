import time

from arduino.app_utils import App
from robot_client import MiniAutoRobot

import vision
from strategy import (ALIGN_MAX_MOVES, BACKUP, CHECK_EVERY, DRIBBLE, DRIBBLE_MAX_PULSES,
                      ESCAPED_Y, Observation, ball_still_ours, decide_action,
                      lost_ball_action, trusted_goal)

# Start with DRY_RUN = True: the car prints what it WOULD do but never moves.
# Switch to False only after the printed decisions look right.
DRY_RUN = False

RUN_TIME_LIMIT_S = 30   # overall cap on one goal attempt
STALE_S = 1.5           # newest frame older than this -> video is stale, stop
SETTLE_S = 0.05         # only trust frames that arrived this long after a move ended
MISS_LIMIT = 3          # this many fresh frames in a row without the ball -> stop
FRAME_WAIT_S = 3.0      # give up if no post-move frame arrives within this time
                        # (the camera here gives ~3 fps with occasional 2 s pauses)
ULTRASONIC_VALID_CM = (2, 400)  # outside this range the reading is garbage -> unknown
GOAL_MEMORY_S = 1.0     # cones flicker between frames: reuse the last goal this long (until a turn)

robot = MiniAutoRobot()
camera = vision.FrameSource()
detector = vision.Detector()


def wait_for_motor_chip(limit_s: float = 90) -> None:
    """After an app restart the MCU can take a while to answer Bridge calls;
    keep asking instead of crashing on the first 10 s timeout."""
    start = time.monotonic()
    while True:
        try:
            robot.stop()
            return
        except TimeoutError:
            waited = time.monotonic() - start
            if waited > limit_s:
                raise
            print(f"[WAIT] motor chip not answering yet ({waited:.0f} s); retrying")


def fresh_frame(after: float):
    """Wait for a frame that arrived after the robot stopped moving."""
    deadline = time.monotonic() + FRAME_WAIT_S
    while time.monotonic() < deadline:
        if camera.latest_time() >= after + SETTLE_S:  # cheap check; decode only once
            return camera.latest()
        time.sleep(0.02)
    return None, 0.0


def distance_cm(sensors: dict) -> float:
    cm = sensors.get("ultrasonic_cm", -1)
    low, high = ULTRASONIC_VALID_CM
    return cm if low <= cm <= high else -1


def move(action) -> float:
    """Run one pulse (or pretend to, in DRY_RUN); return when it ended."""
    if DRY_RUN:
        time.sleep(0.3)  # pretend to move, so the console stays readable
    else:
        robot.drive(action.command, speed=action.speed, ms=action.ms)  # blocks until done
    return time.monotonic()


def goal_attempt() -> None:
    end_time = time.monotonic() + RUN_TIME_LIMIT_S
    last_move_end = time.monotonic()
    misses = 0
    last_ball = None
    dribble_pulses = 0  # > 0 while the ball is at the bumper and we push straight
    checking = False    # True right after backing up to look for the ball
    looked_back = False # True once we've backed up for the current disappearance
    align_moves = 0     # moves spent lining up with the goal (limited by ALIGN_MAX_MOVES)
    remembered_goal, remembered_at = None, 0.0  # cones flicker: keep the goal ~1 s
    while time.monotonic() < end_time:
        sensors = robot.read_sensors()  # one I2C read per decision: run state + distance
        if not sensors.get("program_enabled"):
            return
        img, t = fresh_frame(after=last_move_end)
        if img is None or time.monotonic() - t > STALE_S:
            print(f"[STOP] video stale or unavailable "
                  f"(newest frame {camera.age():.1f} s old, {camera.fps():.1f} fps)")
            return

        ball, goal = detector.detect(img)
        goal = trusted_goal(goal)
        if goal is not None:
            remembered_goal, remembered_at = goal, time.monotonic()
        elif remembered_goal and time.monotonic() - remembered_at <= GOAL_MEMORY_S:
            goal = remembered_goal

        if checking:  # this frame was taken after backing up
            checking = False
            if ball_still_ours(ball):
                print(f"[CHECK] ball still in front ({ball}); keep pushing")
            elif ball is not None:
                print(f"[CHECK] ball slipped ({ball}); chasing it again")
                dribble_pulses = 0
            else:
                print("[CHECK] ball gone after backing up; looking once more")
                dribble_pulses = 0  # fall through to the lost-ball handling below

        if dribble_pulses:
            if ball is not None and ball.y < ESCAPED_Y:
                print(f"[CHASE] ball rolled away ({ball}); chasing it again")
                dribble_pulses = 0
            elif dribble_pulses % CHECK_EVERY == 0 and not checking:
                print(f"[CHECK] backing up to look for the ball -> {BACKUP}")
                last_move_end = move(BACKUP)
                checking = True
                dribble_pulses += 1
                continue
            else:
                print(f"[DRIBBLE {dribble_pulses}/{DRIBBLE_MAX_PULSES}] goal={goal} -> {DRIBBLE}")
                last_move_end = move(DRIBBLE)
                dribble_pulses += 1
                if dribble_pulses > DRIBBLE_MAX_PULSES:
                    print("[DONE] goal attempt finished")
                    return
                continue

        if ball is None:
            look = lost_ball_action(last_ball) if misses == 0 and not looked_back else None
            if look:
                print(f"[LOOK] ball gone (last seen {last_ball}); backing up to look -> {look}")
                last_move_end = move(look)
                looked_back = True  # only once per disappearance
                continue
            misses += 1
            print(f"[MISS {misses}/{MISS_LIMIT}] no ball (goal={goal})")
            if misses >= MISS_LIMIT:
                print("[STOP] ball lost")
                return
            last_move_end = t  # don't move; wait for the next frame
            continue
        misses = 0
        last_ball = ball
        looked_back = False

        print(f"[CAM] {camera.fps():.1f} fps")
        obs = Observation(ball=ball, goal=goal, distance_cm=distance_cm(sensors),
                          allow_align=align_moves < ALIGN_MAX_MOVES)
        action = decide_action(obs)
        print(f"{obs} -> {action}")
        if action is None:
            return
        last_move_end = move(action)
        if action.command.startswith("rotate"):
            remembered_goal = None  # turning moves where the goal appears
        if action.aligning:
            align_moves += 1
            if align_moves == ALIGN_MAX_MOVES:
                print(f"[ALIGN] no line-up after {ALIGN_MAX_MOVES} moves; just chase and push")
        if action.starts_dribble:
            dribble_pulses = 1
        if action.final:
            print("[DONE] goal attempt finished")
            return
    print("[STOP] time limit reached")


try:
    wait_for_motor_chip()
    print(f"health  : {robot.health()}")
    print(f"sensors : {robot.read_sensors()}")
    print(f"DRY_RUN = {DRY_RUN}. Short-press the camera BOOT button to start a goal attempt.")
    App.run(user_loop=lambda: robot.run_program(goal_attempt))
finally:
    try:
        robot.stop()
    except TimeoutError:
        print("[WARN] final stop not answered; the MCU's own drive timer still stops the motors")
    detector.close()
